<?php 

// Exit if class does not exist.
if(!class_exists( 'YITH_WCWL' )) return;

$icon = flatsome_option('wishlist_icon');
$icon_style = flatsome_option('wishlist_icon_style'); 

?>
<li class="header-wishlist-icon">
  <?php if($icon_style) { ?><div class="header-button"><?php } ?>
  <a href="<?php echo YITH_WCWL()->get_wishlist_url(); ?>" class="wishlist-link <?php echo get_flatsome_icon_class($icon_style, 'small'); ?>">
  	<?php if(flatsome_option('wishlist_title')) { ?>
    <span class="hide-for-medium header-wishlist-title">
  	  <?php if(flatsome_option('header_wishlist_label')) {echo flatsome_option('header_wishlist_label');} else{ _e('Wishlist', 'woocommerce');} ?>
  	</span>
    <?php } ?>
    <?php if($icon){ ?>
      <img class="cart-img-icon" alt="Wishlist" width="22px" src="https://indumentaria.bitobee.com/wp-content/uploads/2022/06/Heart.svg"
        <?php if(YITH_WCWL()->count_products() > 0){ ?>data-icon-label="<?php echo YITH_WCWL()->count_products() ; ?>" <?php } ?>>
    <?php } ?>
  </a>
  <?php if($icon_style) { ?> </div> <?php } ?>
</li>